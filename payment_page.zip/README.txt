Payment Page

1. index.html को खोलें.
2. ऊपर वाले बॉक्स में अपनी image दिखाने के लिए image का नाम banner.jpg रखें और उसे index.html के साथ इसी folder में रखें.
3. Payment button में दिया गया UPI link आपके भेजे हुए code के अनुसार रखा गया है.
